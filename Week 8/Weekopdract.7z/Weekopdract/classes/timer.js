class shop {
    constructor(opened, closed) {
        
    }
}